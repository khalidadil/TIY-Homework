window.onload = initial;

function initial(){
	console.log("IS THIS WORKING??");
	// document.querySelector('.button').style.background="yellow";
};

// var buttonClick = document.getElementById('.button');
// console.log(button);

// buttonClick.style.cursor = 'pointer';
// buttonClick.onclick = function() {
//     this.style.backgroundColor = "red";
//     console.log("IS THIS WORKING???");
// };

 var divs = [];
 var images = ['shorts', 'jersey','shoe'];
 var i = 0;
 var prod_list = [{title:'item1', price:10.27, img:'shorts'}, {title:'item2', price:9.81, img:'shorts'},{title:'item3', price:8.39, img:'shorts'}];

// for (var j=0; j<3; j++){
// 	 divs[j] = document.getElementsByClassName('button')[j];

// 	 divs[j].addEventListener('click', function (event) {
// 	 	 	document.getElementsByClassName('items')[j].style.visibility='hidden';
// 	 		document.getElementsByClassName('prod_img')[j].style.visibility='visible';
// 	 		document.getElementsByClassName('prod_img')[j].innerHTML ='<h1>Added to Cart!</h1>';
// 	 		window.setTimeout(function (){
// 	 			document.getElementsByClassName('items')[j].style.visibility='visible';
// 	 			document.getElementsByClassName('item_title')[j].innerHTML ='New Product';
// 	 			document.getElementsByClassName('prod_img')[j].innerHTML ='';
// 	 			document.getElementsByClassName('prod_img')[j].style.background ='url(img/' + images[i] + '.jpg) no-repeat center';
// 	 			document.getElementsByClassName('prod_img')[j].style.backgroundSize ='cover';
// 	 			i++;
// 	 		},1000);
// 	 });
// };

function qsa(selector, element){
	return (element || document).querySelectorAll(selector);
}

function qs(selector, element){
	return (element || document).querySelector(selector);
}

// function handleBuyButtonClicks(index){
// 	var items = qsa('.items')[index];
// 	var button = qs('.button', items);
// 	var title = qs('.item_title', items);
// 	var prod_img = qs('.prod_img', items);
	
// 	div = button;

// 	div.addEventListener('click', function (event) {
// 	 		items.style.visibility='hidden';
// 	 		prod_img.style.visibility='visible';
// 	 		prod_img.innerHTML ='<h1>Added to Cart!</h1>';
// 	 		window.setTimeout(function (){
// 	 			items.style.visibility='visible';
// 	 			title.innerHTML ='New Product';
// 	 			prod_img.innerHTML ='';
// 	 			prod_img.style.background ='url(img/' + images[0] + '.jpg) no-repeat center';
// 	 			prod_img.style.backgroundSize ='cover';
// 	 		},1000);
// 	});
// }


function handleBuyButtonClicks(index){
	var items = qsa('.items')[index];
	var dynamic = qs('.dynamic', items);
	var button = qs('.button', items);
	var title = qs('.item_title', items);
	var prod_img = qs('.prod_img', items);
	
	div = button;

	div.addEventListener('click', function (event) {
	 		dynamic.style.visibility='hidden';

	 		var new_title = document.createElement('li');
	 		new_title.className = "item_title";
	 		new_title.innerHTML = prod_list[0].title;

	 		var new_img = document.createElement('li');
	 		new_img.className = "prod_img";

	 		prod_img.innerHTML ='<h1>Added to Cart!</h1>';

	 		dynamic.appendChild(prod_img);

	 		// window.setTimeout(function (){
	 		// 	items.style.visibility='visible';
	 		// 	title.innerHTML ='New Product';
	 		// 	prod_img.innerHTML ='';
	 		// 	prod_img.style.background ='url(img/' + images[0] + '.jpg) no-repeat center';
	 		// 	prod_img.style.backgroundSize ='cover';
	 		// },1000);
	});
}
/*var li = document.createElement('li');
        li.innerText = quote;
        ul.appendChild(li);*/

for(var j = 0; j < 3; j++){
	handleBuyButtonClicks(j);
}